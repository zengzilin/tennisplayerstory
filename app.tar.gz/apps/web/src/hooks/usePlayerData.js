
import { useState, useEffect } from 'react';
import pb from '@/lib/pocketbaseClient';

export const usePlayerData = () => {
  const [players, setPlayers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    const fetchPlayers = async () => {
      try {
        console.log('usePlayerData: Fetching all players from PocketBase...');
        // Use getFullList to fetch all records instead of limiting to the first 200
        const result = await pb.collection('players').getFullList({
          sort: 'ranking',
          $autoCancel: false,
        });
        
        console.log(`usePlayerData: Successfully fetched ${result.length} players total.`, {
          atp: result.filter(p => p.source === 'atp').length,
          wta: result.filter(p => p.source === 'wta').length,
          itf: result.filter(p => p.source === 'itf').length
        });

        if (!cancelled) {
          setPlayers(result);
        }
      } catch (err) {
        console.error('usePlayerData: Failed to fetch players:', err);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    fetchPlayers();
    return () => { cancelled = true; };
  }, []);

  return { players, loading };
};
