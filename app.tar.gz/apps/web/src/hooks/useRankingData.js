
import { useState, useEffect } from 'react';
import pb from '@/lib/pocketbaseClient';

export const useRankingData = () => {
  const [rankings, setRankings] = useState({ atp: [], wta: [] });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    const fetchRankings = async () => {
      try {
        console.log('useRankingData: Fetching ATP and WTA rankings...');
        
        // Use getFullList to ensure we don't truncate records if there are > 100
        const [atpResult, wtaResult] = await Promise.all([
          pb.collection('players').getFullList({
            filter: 'source = "atp"',
            sort: 'ranking',
            $autoCancel: false,
          }),
          pb.collection('players').getFullList({
            filter: 'source = "wta"',
            sort: 'ranking',
            $autoCancel: false,
          }),
        ]);

        console.log('useRankingData: Fetched ranking data:', { 
          atpCount: atpResult.length, 
          wtaCount: wtaResult.length 
        });

        if (!cancelled) {
          const toRankingRow = (p, i) => ({
            id: p.id,
            position: p.ranking || i + 1,
            name: p.name,
            country: p.country,
            points: p.points,
            tournaments: null,
            trend: 'same',
            source: p.source
          });

          setRankings({
            atp: atpResult.map(toRankingRow),
            wta: wtaResult.map(toRankingRow),
          });
        }
      } catch (err) {
        console.error('useRankingData: Failed to fetch rankings:', err);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    fetchRankings();
    return () => { cancelled = true; };
  }, []);

  return { rankings, loading };
};
