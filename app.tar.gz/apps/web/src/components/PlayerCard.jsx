
import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Trophy, Award, Heart } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext.jsx';
import { useTranslation } from 'react-i18next';
import { toast } from 'sonner';
import ImageWithAlt from '@/components/ImageWithAlt.jsx';

const PlayerCard = ({ player }) => {
  const { isAuthenticated, currentUser, updateUser } = useAuth();
  const { t } = useTranslation();
  const [isSaving, setIsSaving] = useState(false);

  const favoritePlayers = currentUser?.favorite_players || [];
  const isFavorited = favoritePlayers.includes(player.id);

  const handleToggleFavorite = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!isAuthenticated) return;
    
    setIsSaving(true);
    try {
      let newFavorites;
      if (isFavorited) {
        newFavorites = favoritePlayers.filter(id => id !== player.id);
      } else {
        newFavorites = [...favoritePlayers, player.id];
      }
      
      await updateUser(currentUser.id, { favorite_players: newFavorites });
      toast.success(isFavorited ? t('playerCard.removeFromFav') : t('playerCard.addToFav'));
    } catch (error) {
      console.error('Error updating favorites:', error);
      toast.error(t('playerCard.favError'));
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-all duration-200 hover:-translate-y-1 group relative">
      <div className="aspect-square overflow-hidden bg-muted relative">
        <ImageWithAlt
          src={player.image}
          alt={`Portrait of tennis player ${player.name} from ${player.country}`}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        {isAuthenticated && (
          <Button
            variant="secondary"
            size="icon"
            className={`absolute top-3 right-3 rounded-full shadow-md transition-all duration-200 ${
              isFavorited ? 'bg-primary text-primary-foreground hover:bg-primary/90' : 'bg-background/80 backdrop-blur-sm hover:bg-background'
            }`}
            onClick={handleToggleFavorite}
            disabled={isSaving}
            aria-label={isFavorited ? t('playerCard.removeFromFav') : t('playerCard.addToFav')}
          >
            <Heart className={`h-5 w-5 ${isFavorited ? 'fill-current' : ''} ${isSaving ? 'animate-pulse' : ''}`} />
          </Button>
        )}
      </div>
      <CardContent className="p-6 space-y-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-xl truncate pr-2">{player.name}</h3>
            <Badge variant="secondary" className="text-lg font-bold shrink-0">
              #{player.ranking}
            </Badge>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <span className="text-2xl">{player.flag}</span>
            <span className="text-sm">{player.country}</span>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4 pt-4 border-t border-border">
          <div className="space-y-1">
            <div className="flex items-center gap-1 text-muted-foreground text-sm">
              <Trophy className="h-4 w-4" />
              <span>{t('playerCard.titles')}</span>
            </div>
            <p className="text-2xl font-bold">{player.titles}</p>
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-1 text-muted-foreground text-sm">
              <Award className="h-4 w-4" />
              <span>{t('playerCard.grandSlams')}</span>
            </div>
            <p className="text-2xl font-bold">{player.grandSlams}</p>
          </div>
        </div>
        <div className="text-sm text-muted-foreground">
          <span className="font-medium text-foreground">{player.points?.toLocaleString()}</span> {t('playerCard.points')}
        </div>
      </CardContent>
    </Card>
  );
};

export default PlayerCard;
